#!/bin/bash

echo "Uninstalling ALCPlugFix..."

sudo rm -rf /usr/local/bin/ALCPlugFix
sudo rm /usr/local/bin/hda-verb
sudo rm /usr/local/bin/boot-patch
sudo launchctl unload -w /Library/LaunchDaemons/good.win.ALCPlugFix.plist
sudo launchctl unload -w /Library/LaunchDaemons/swanux.ALCBootFix.plist
sudo launchctl remove good.win.ALCPlugFix
sudo launchctl remove swanux.ALCBootFix.plist
sudo rm /Library/LaunchDaemons/good.win.ALCPlugFix.plist
sudo rm /Library/LaunchDaemons/swanux.ALCBootFix.plist

echo "Done!"
exit 0
